using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain.Entities;
namespace Application.Interfaces
{
    public interface IEncounterRepository
    {
        Task<Encounter> AddAsync(Encounter encounter);
        Task<IEnumerable<Encounter>> GetByPatientIdAsync(Guid patientId);
        Task<Encounter?> GetByIdAsync(Guid id);
        Task UpdateAsync(Encounter encounter);
        Task DeleteAsync(Guid id);
    }
}
