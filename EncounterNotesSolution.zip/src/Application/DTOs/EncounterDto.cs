using System;

namespace Application.DTOs
{
    public record EncounterDto(Guid Id, Guid PatientId, DateTime Date, string Symptoms, string Diagnosis, string Treatment);
    public record CreateEncounterRequest(Guid PatientId, string Symptoms, string Diagnosis, string Treatment);
}
