using Microsoft.AspNetCore.Mvc;
using Application.DTOs;
using Application.Interfaces;
using Domain.Entities;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EncountersController : ControllerBase
    {
        private readonly IEncounterRepository _repo;
        public EncountersController(IEncounterRepository repo) { _repo = repo; }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateEncounterRequest req)
        {
            var ent = new Encounter
            {
                PatientId = req.PatientId,
                Symptoms = req.Symptoms,
                Diagnosis = req.Diagnosis,
                Treatment = req.Treatment
            };
            var created = await _repo.AddAsync(ent);
            var dto = new EncounterDto(created.Id, created.PatientId, created.Date, created.Symptoms, created.Diagnosis, created.Treatment);
            return CreatedAtAction(nameof(GetById), new { id = dto.Id }, dto);
        }

        [HttpGet("patient/{patientId}")]
        public async Task<IActionResult> GetByPatient(Guid patientId)
        {
            var list = await _repo.GetByPatientIdAsync(patientId);
            var dtos = list.Select(x => new EncounterDto(x.Id, x.PatientId, x.Date, x.Symptoms, x.Diagnosis, x.Treatment));
            return Ok(dtos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var e = await _repo.GetByIdAsync(id);
            if (e == null) return NotFound();
            return Ok(new EncounterDto(e.Id, e.PatientId, e.Date, e.Symptoms, e.Diagnosis, e.Treatment));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] CreateEncounterRequest req)
        {
            var e = await _repo.GetByIdAsync(id);
            if (e == null) return NotFound();
            e.Symptoms = req.Symptoms;
            e.Diagnosis = req.Diagnosis;
            e.Treatment = req.Treatment;
            await _repo.UpdateAsync(e);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _repo.DeleteAsync(id);
            return NoContent();
        }
    }
}
