using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Entities;
using Application.Interfaces;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Repositories
{
    public class EncounterRepository : IEncounterRepository
    {
        private readonly AppDbContext _db;
        public EncounterRepository(AppDbContext db) { _db = db; }

        public async Task<Encounter> AddAsync(Encounter encounter)
        {
            _db.Encounters.Add(encounter);
            await _db.SaveChangesAsync();
            return encounter;
        }

        public async Task DeleteAsync(Guid id)
        {
            var e = await _db.Encounters.FindAsync(id);
            if (e != null) { _db.Encounters.Remove(e); await _db.SaveChangesAsync(); }
        }

        public async Task<Encounter?> GetByIdAsync(Guid id)
        {
            return await _db.Encounters.FindAsync(id);
        }

        public async Task<IEnumerable<Encounter>> GetByPatientIdAsync(Guid patientId)
        {
            return await _db.Encounters.Where(x => x.PatientId == patientId).OrderByDescending(x=>x.Date).ToListAsync();
        }

        public async Task UpdateAsync(Encounter encounter)
        {
            _db.Encounters.Update(encounter);
            await _db.SaveChangesAsync();
        }
    }
}
