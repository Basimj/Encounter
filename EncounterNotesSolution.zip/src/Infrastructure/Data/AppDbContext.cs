using Microsoft.EntityFrameworkCore;
using Domain.Entities;

namespace Infrastructure.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options) { }

        public DbSet<Encounter> Encounters { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Encounter>(e =>
            {
                e.HasKey(x => x.Id);
                e.Property(x => x.Symptoms).HasMaxLength(2000);
                e.Property(x => x.Diagnosis).HasMaxLength(2000);
                e.Property(x => x.Treatment).HasMaxLength(2000);
            });
            base.OnModelCreating(modelBuilder);
        }
    }
}
