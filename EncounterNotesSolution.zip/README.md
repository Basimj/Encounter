# EncounterNotesSolution

هيكل مشروع بسيط يطبق Clean Architecture لتسجيل ملاحظات الزيارات الطبية.

المجلدات:
- src/Domain  : الكيانات الأساسية.
- src/Application : DTOs وواجهات المستودع.
- src/Infrastructure : DbContext وRepository (InMemory DB مُعد افتراضياً).
- src/WebApi : API جاهز للاستدعاء.
- src/BlazorClient : صفحة Blazor بسيطة لعرض وإنشاء الملاحظات.

تشغيل سريع:
1. انتقل إلى `src/WebApi` وشغّل الأمر:
   `dotnet run`
   هذا سيشغّل API على المنفذ المعين عادة 5000/5001.

2. يمكنك تشغيل Blazor Client بعد تهيئته كـ Blazor WebAssembly أو Blazor Server حسب تفضيلك.
   حاليا ملفات Blazor مصغرة كنقطة انطلاق.

ملاحظات:
- المشروع يستخدم InMemory database في WebApi. لتغييرها إلى SQL Server قم بتعديل AppDbContext في `Program.cs`.
- صيغ الملفات مكتوبة بالعربية في واجهات Blazor.
